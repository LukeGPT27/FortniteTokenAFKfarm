@echo off
cd /d "%~dp0"
echo [1/2] Installing packages...
py -m pip install -r requirements.txt || goto :err
echo.
echo [2/2] Building exe...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name QueueBot main.py || goto :err
echo.
echo Done. Your exe: dist\QueueBot.exe
pause
exit /b 0
:err
echo.
echo Something failed - scroll up to see why.
pause
exit /b 1
