"""
QueueBot - auto-queue / AFK / requeue helper with a premium translucent UI (keyless).

Loop: click Play -> wait in queue -> detect match start -> idle until the
match ends -> click leave/continue buttons -> lobby -> requeue.
Buttons are found by image matching; capture them once in SETTINGS.
"""

import datetime
import math
import os
import random
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import (Qt, QTimer, QPropertyAnimation, QVariantAnimation, QEasingCurve,
                            QRectF, QPointF, QPoint, QRect, Signal, QObject)
from PySide6.QtGui import (QPainter, QColor, QPen, QFont, QPainterPath, QShortcut, QKeySequence,
                           QRadialGradient, QLinearGradient, QPolygonF)
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
                               QTextEdit, QSlider, QCheckBox, QDoubleSpinBox, QSpinBox, QComboBox,
                               QLineEdit, QMessageBox, QGraphicsOpacityEffect, QGraphicsDropShadowEffect,
                               QStackedWidget, QScrollArea, QFrame)

import pyautogui

try:
    import pygetwindow as gw
except Exception:
    gw = None
try:
    import keyboard as kb
except Exception:
    kb = None

# =====================================================================
#  BRANDING - change these to whatever you want
# =====================================================================
TITLE_1 = "QUEUE"
TITLE_2 = "AUTOMATION"
VERSION = "v1.0"

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.05

BASE_DIR = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
TEMPLATE_DIR = BASE_DIR / "templates"
LOG_FILE = BASE_DIR / "bot_log.txt"
TEMPLATE_DIR.mkdir(exist_ok=True)

CATEGORIES = {
    "play": "the Play / Ready button in the lobby",
    "ingame": "something only visible during a match (bus icon, minimap)",
    "end": "Leave Match / Confirm / Return to Lobby / Continue buttons",
}
STATE_NAMES = {"IDLE": "--", "LOBBY": "Lobby", "QUEUE": "Queueing", "MATCH": "In match", "POST": "Leaving"}

ACCENT = QColor("#b9f23c")
ORANGE = QColor("#ff9d1c")
WHITE = QColor("#eceef4")
ICE = QColor("#cfe3ff")
DIM = QColor("#8187a8")
RED = QColor("#ff5470")


def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t), int(a.alpha() + (b.alpha() - a.alpha()) * t))


# =====================================================================
#  thread-safe bridge
# =====================================================================
class Bridge(QObject):
    log = Signal(str)
    show_window = Signal()
    emergency = Signal()


bridge = Bridge()


# =====================================================================
#  BOT
# =====================================================================
class Bot:
    def __init__(self, settings):
        self.s = settings
        self.stop_event = threading.Event()
        self.thread = None
        self.state = "IDLE"
        self.matches = 0
        self.queued = 0
        self.last_click = "--"

    def log(self, msg):
        bridge.log.emit(msg)

    def start(self):
        if self.running():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def running(self):
        return self.thread is not None and self.thread.is_alive()

    def _sleep(self, seconds):
        end = time.time() + seconds
        while time.time() < end and not self.stop_event.is_set():
            time.sleep(0.1)

    def files(self, prefix):
        return sorted(TEMPLATE_DIR.glob(f"{prefix}*.png"))

    def find(self, prefix):
        for f in self.files(prefix):
            try:
                pt = pyautogui.locateCenterOnScreen(str(f), confidence=float(self.s["confidence"]), grayscale=True)
                if pt:
                    return pt
            except pyautogui.FailSafeException:
                raise
            except Exception:
                continue
        return None

    def _click(self, pt):
        pyautogui.moveTo(pt.x + random.randint(-3, 3), pt.y + random.randint(-3, 3),
                         duration=random.uniform(0.15, 0.4))
        pyautogui.click()
        self.last_click = datetime.datetime.now().strftime("%H:%M:%S")

    def _click_any(self, prefix):
        pt = self.find(prefix)
        if pt:
            self._click(pt)
            return True
        return False

    def _focus_game(self):
        if gw is None:
            return
        try:
            wins = gw.getWindowsWithTitle("Fortnite")
            if wins:
                if wins[0].isMinimized:
                    wins[0].restore()
                wins[0].activate()
        except Exception:
            pass

    def _run(self):
        self.log("Bot started.")
        missing = [c for c in CATEGORIES if not self.files(c)]
        if missing:
            self.log("ERROR: no templates captured for: " + ", ".join(missing))
            return
        s = self.s
        state = "LOBBY"
        queue_start = match_start = post_start = 0.0
        last_idle = time.time()
        self.state = state
        try:
            while not self.stop_event.is_set():
                if state == "LOBBY":
                    self._focus_game()
                    if self._click_any("play"):
                        self.queued += 1
                        self.log(f"Clicked Play, queueing (#{self.queued})")
                        if s["press_key"] and s["key"].strip():
                            pyautogui.press(s["key"].strip().lower())
                        queue_start = time.time()
                        state = "QUEUE"
                        self._sleep(5)
                    else:
                        if self._click_any("end"):
                            self.log("Clicked a continue/leave button")
                        self._sleep(2)

                elif state == "QUEUE":
                    if self.find("ingame"):
                        self.matches += 1
                        match_start = last_idle = time.time()
                        self.log(f"Match #{self.matches} started, going AFK")
                        state = "MATCH"
                    elif time.time() - queue_start > s["queue_timeout"] * 60:
                        self.log("Queue timeout, retrying")
                        self._click_any("end")
                        state = "LOBBY"
                    elif time.time() - queue_start > 20 and self.find("play"):
                        self.log("Play button is back, queue failed. Retrying")
                        state = "LOBBY"
                    else:
                        self._sleep(s["interval"])

                elif state == "MATCH":
                    if s["anti_idle"] and time.time() - last_idle > s["idle_every"]:
                        dx, dy = random.choice([(4, 0), (-4, 0), (0, 4), (0, -4)])
                        pyautogui.moveRel(dx, dy, duration=0.1)
                        last_idle = time.time()
                    if self.find("end"):
                        self.log(f"Match over after {(time.time() - match_start) / 60:.1f} min, leaving")
                        post_start = time.time()
                        state = "POST"
                    elif time.time() - match_start > s["max_match"] * 60:
                        self.log("Max match time reached, still watching for exit buttons")
                        match_start = time.time()
                    else:
                        self._sleep(s["interval"])

                elif state == "POST":
                    if self.find("play"):
                        self.log("Back in lobby")
                        state = "LOBBY"
                    elif self._click_any("end"):
                        self.log("Clicked leave/continue")
                        self._sleep(2)
                    elif time.time() - post_start > 120:
                        self.log("Stuck on post-game for 2 min, resetting")
                        state = "LOBBY"
                    else:
                        self._sleep(1.5)
                self.state = state
        except pyautogui.FailSafeException:
            self.log("ERROR: failsafe (mouse in corner), stopped")
        except Exception as e:
            self.log(f"ERROR: {e!r}")
        finally:
            self.state = "IDLE"
            self.log("Bot stopped.")


# =====================================================================
#  custom widgets
# =====================================================================
STYLES = {
    "accent": (QColor("#b9f23c"), QColor("#d3ff6a"), QColor("#10130a")),
    "danger": (QColor("#ff5470"), QColor("#ff8499"), QColor("#ffffff")),
    "dark": (QColor(255, 255, 255, 18), QColor(255, 255, 255, 46), QColor("#e8eaf5")),
    "ghost": (QColor(255, 255, 255, 14), QColor(255, 255, 255, 40), QColor("#eceef4")),
}


class AnimButton(QWidget):
    clicked = Signal()

    def __init__(self, text, kind="ghost", size=10, height=34, skew=False, family="Bahnschrift",
                 italic=False, spacing=1.0):
        super().__init__()
        self.text = text
        self.kind = kind
        self.skew = skew
        self.setFixedHeight(height)
        self.setCursor(Qt.PointingHandCursor)
        f = QFont(family, size)
        f.setBold(True)
        f.setItalic(italic)
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
        self.setFont(f)
        self._hover = 0.0
        self._press = False
        self._old = STYLES[kind]
        self._new = STYLES[kind]
        self._mix = 1.0
        self._ph = 1.2
        self.a_hover = QVariantAnimation(self)
        self.a_hover.setDuration(150)
        self.a_hover.valueChanged.connect(self._set_hover)
        self.a_kind = QVariantAnimation(self)
        self.a_kind.setDuration(300)
        self.a_kind.setStartValue(0.0)
        self.a_kind.setEndValue(1.0)
        self.a_kind.valueChanged.connect(self._set_mix)
        if skew:
            t = QTimer(self)
            t.timeout.connect(self._shimmer)
            t.start(30)

    def _shimmer(self):
        self._ph = (self._ph + 0.012) % 1.7
        if self._ph <= 1.0:
            self.update()

    def _set_hover(self, v):
        self._hover = float(v)
        self.update()

    def _set_mix(self, v):
        self._mix = float(v)
        self.update()

    def _current(self):
        return tuple(lerp(self._old[i], self._new[i], self._mix) for i in range(3))

    def set_kind(self, kind):
        if kind == self.kind:
            return
        self._old = self._current()
        self._new = STYLES[kind]
        self.kind = kind
        self._mix = 0.0
        self.a_kind.stop()
        self.a_kind.start()

    def set_text(self, text):
        self.text = text
        self.update()

    def _fade_hover(self, to):
        self.a_hover.stop()
        self.a_hover.setStartValue(self._hover)
        self.a_hover.setEndValue(to)
        self.a_hover.start()

    def enterEvent(self, e):
        self._fade_hover(1.0)

    def leaveEvent(self, e):
        self._press = False
        self._fade_hover(0.0)
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = True
            self.update()

    def mouseReleaseEvent(self, e):
        was = self._press
        self._press = False
        self.update()
        if was and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()

    def paintEvent(self, e):
        base, hover, fg = self._current()
        fill = lerp(base, hover, self._hover)
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        dy = 1.5 if self._press else 0.0

        if self.skew:
            m, s = 8.0, 11.0
            x0, y0, x1, y1 = m, m + dy, w - m, h - m + dy
            path = QPainterPath()
            path.moveTo(x0 + s, y0)
            path.lineTo(x1, y0)
            path.lineTo(x1 - s, y1)
            path.lineTo(x0, y1)
            path.closeSubpath()
            for wd, al in ((15, 14), (10, 24), (5, 40)):
                c = QColor(fill)
                c.setAlpha(int(al * (0.6 + 0.9 * self._hover)))
                pen = QPen(c, wd)
                pen.setJoinStyle(Qt.RoundJoin)
                p.setPen(pen)
                p.setBrush(Qt.NoBrush)
                p.drawPath(path)
            p.setPen(Qt.NoPen)
            p.setBrush(fill)
            p.drawPath(path)
            if self._ph <= 1.0:
                p.setClipPath(path)
                sx = x0 - 50 + self._ph * ((x1 - x0) + 100)
                streak = QPolygonF([QPointF(sx, y0), QPointF(sx + 30, y0),
                                    QPointF(sx + 30 - s, y1), QPointF(sx - s, y1)])
                p.setBrush(QColor(255, 255, 255, 70))
                p.drawPolygon(streak)
                p.setClipping(False)
            p.setPen(fg)
            p.setFont(self.font())
            p.drawText(QRectF(x0, y0, x1 - x0, y1 - y0), Qt.AlignCenter, self.text)
        else:
            r = QRectF(self.rect()).adjusted(1, 1 + dy, -1, -1)
            p.setBrush(fill)
            if self.kind == "ghost":
                p.setPen(QPen(QColor(255, 255, 255, 38 + int(40 * self._hover)), 1))
            else:
                p.setPen(Qt.NoPen)
            p.drawRoundedRect(r, 3 if self.kind == "dark" else 7, 3 if self.kind == "dark" else 7)
            p.setPen(fg)
            p.setFont(self.font())
            p.drawText(r, Qt.AlignCenter, self.text)


class Hero(QWidget):
    """Glowing compass emblem with drifting embers. Speeds up while the bot is running."""

    def __init__(self):
        super().__init__()
        self.setFixedHeight(165)
        self.t = 0.0
        self.angle = 0.0
        self.speed = 0.35
        self.target = 0.35
        self.rate = 0.25
        self.parts = []
        timer = QTimer(self)
        timer.timeout.connect(self._tick)
        timer.start(16)

    def set_active(self, on):
        self.target = 3.0 if on else 0.35
        self.rate = 0.9 if on else 0.25

    def _tick(self):
        self.t += 0.016
        self.speed += (self.target - self.speed) * 0.04
        self.angle = (self.angle + self.speed) % 360
        cx = self.width() / 2
        if random.random() < self.rate and len(self.parts) < 80:
            self.parts.append([cx + random.uniform(-55, 55), 128 + random.uniform(-10, 10),
                               random.uniform(-0.2, 0.2), random.uniform(-0.95, -0.3), 1.0,
                               random.uniform(1.1, 2.8), random.random() < 0.55])
        for q in self.parts:
            q[0] += q[2] + math.sin(self.t * 3 + q[1] * 0.05) * 0.18
            q[1] += q[3]
            q[4] -= 0.008
        self.parts = [q for q in self.parts if q[4] > 0]
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        cx, cy = self.width() / 2, 82.0
        act = max(0.0, min(1.0, (self.speed - 0.35) / 2.65))
        breath = 0.85 + 0.15 * math.sin(self.t * 2.0)

        grad = QRadialGradient(cx, cy, 118)
        grad.setColorAt(0.0, QColor(255, 150, 30, int(195 * breath)))
        grad.setColorAt(0.5, QColor(190, 85, 10, int(100 * breath)))
        grad.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(grad)
        p.drawEllipse(QPointF(cx, cy), 118, 118)

        p.setPen(QPen(QColor(255, 205, 90, 80), 1.5))
        for i in range(48):
            a = math.radians(i * 7.5 + self.angle * 0.2)
            r1, r2 = 71, (75 if i % 4 else 79)
            p.drawLine(QPointF(cx + r1 * math.cos(a), cy + r1 * math.sin(a)),
                       QPointF(cx + r2 * math.cos(a), cy + r2 * math.sin(a)))

        pen = QPen(ACCENT, 9)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        outer = QRectF(cx - 60, cy - 60, 120, 120)
        for i in range(3):
            p.drawArc(outer, int((self.angle + i * 120) * 16), int(78 * 16))

        pen = QPen(ORANGE, 5)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        mid = QRectF(cx - 47, cy - 47, 94, 94)
        for i in range(2):
            p.drawArc(mid, int((-self.angle * 1.4 + i * 180) * 16), int(110 * 16))

        p.setBrush(QColor(20, 16, 8, 235))
        p.setPen(QPen(ACCENT, 2.5))
        p.drawEllipse(QPointF(cx, cy), 33, 33)

        p.save()
        p.translate(cx, cy)
        p.rotate(math.sin(self.t * 1.3) * (7 + 20 * act))
        p.setPen(Qt.NoPen)
        p.setBrush(ACCENT)
        p.drawPolygon(QPolygonF([QPointF(0, -56), QPointF(7, 0), QPointF(-7, 0)]))
        p.setBrush(ORANGE)
        p.drawPolygon(QPolygonF([QPointF(0, 56), QPointF(7, 0), QPointF(-7, 0)]))
        p.setBrush(QColor(20, 16, 8))
        p.drawEllipse(QPointF(0, 0), 4, 4)
        p.restore()

        p.setPen(Qt.NoPen)
        for q in self.parts:
            c = QColor(ORANGE if q[6] else ACCENT)
            c.setAlpha(int(255 * max(0.0, q[4])))
            p.setBrush(c)
            p.drawEllipse(QPointF(q[0], q[1]), q[5], q[5])


def make_label(text, size=10, color=WHITE, bold=False, family="Segoe UI", spacing=0.0, italic=False):
    lab = QLabel(text)
    f = QFont(family, size)
    f.setBold(bold)
    f.setItalic(italic)
    if spacing:
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
    lab.setFont(f)
    lab.setStyleSheet(f"color: {color.name()}; background: transparent;")
    return lab


def glow(widget, color, blur=26, alpha=170):
    e = QGraphicsDropShadowEffect(widget)
    e.setBlurRadius(blur)
    e.setOffset(0, 0)
    c = QColor(color)
    c.setAlpha(alpha)
    e.setColor(c)
    widget.setGraphicsEffect(e)


class StatInline(QLabel):
    def __init__(self, prefix, value="0"):
        super().__init__()
        self.prefix = prefix
        f = QFont("Segoe UI Black", 12)
        f.setItalic(True)
        self.setFont(f)
        self.setText(f"{prefix}: {value}")
        self._v = value
        self.setStyleSheet(f"color: {ACCENT.name()}; background: transparent;")
        self.flash = QVariantAnimation(self)
        self.flash.setDuration(700)
        self.flash.setStartValue(0.0)
        self.flash.setEndValue(1.0)
        self.flash.setEasingCurve(QEasingCurve.OutQuad)
        self.flash.valueChanged.connect(
            lambda v: self.setStyleSheet(f"color: {lerp(WHITE, ACCENT, float(v)).name()}; background: transparent;"))

    def set_value(self, v, flash=True):
        if v == self._v:
            return
        self._v = v
        self.setText(f"{self.prefix}: {v}")
        if flash:
            self.flash.stop()
            self.flash.start()


class Snip(QWidget):
    """Full-screen overlay to drag a rectangle. Emits crop box in screenshot pixels, or None."""
    done = Signal(object)

    def __init__(self, shot):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.shot = shot
        self.a = self.b = None
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setCursor(Qt.CrossCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setGeometry(QApplication.primaryScreen().geometry())
        self.show()
        self.raise_()
        self.activateWindow()
        self.setFocus()

    def _rect(self):
        return QRect(self.a, self.b).normalized()

    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(0, 0, 0, 110))
        if self.a is not None and self.b is not None:
            r = self._rect()
            p.setCompositionMode(QPainter.CompositionMode_Source)
            p.fillRect(r, QColor(0, 0, 0, 1))
            p.setCompositionMode(QPainter.CompositionMode_SourceOver)
            p.setPen(QPen(ACCENT, 2))
            p.drawRect(r)

    def mousePressEvent(self, e):
        self.a = self.b = e.position().toPoint()
        self.update()

    def mouseMoveEvent(self, e):
        if self.a is not None:
            self.b = e.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, e):
        if self.a is None:
            return
        self.b = e.position().toPoint()
        r = self._rect()
        k = self.shot.width / self.width()
        box = None
        if r.width() > 5 and r.height() > 5:
            box = (int(r.left() * k), int(r.top() * k), int(r.right() * k), int(r.bottom() * k))
        self.close()
        self.done.emit(box)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
            self.done.emit(None)


# =====================================================================
#  main window
# =====================================================================
APP_QSS = f"""
QCheckBox {{ color: {WHITE.name()}; spacing: 8px; background: transparent; }}
QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid #5a5f86; border-radius: 3px;
                        background: rgba(255,255,255,10); }}
QCheckBox::indicator:checked {{ background: {ACCENT.name()}; border-color: {ACCENT.name()}; }}
QSpinBox, QDoubleSpinBox, QLineEdit, QComboBox {{
    background: rgba(255,255,255,14); color: {WHITE.name()}; border: 1px solid rgba(255,255,255,40);
    border-radius: 4px; padding: 3px 8px; min-height: 20px; selection-background-color: {ACCENT.name()};
    selection-color: #111; }}
QLineEdit:focus {{ border: 1px solid {ACCENT.name()}; }}
QComboBox QAbstractItemView {{ background: #15123a; color: {WHITE.name()};
    selection-background-color: {ACCENT.name()}; selection-color: #111; border: 1px solid #333; }}
QSlider::groove:horizontal {{ height: 3px; background: rgba(255,255,255,40); border-radius: 1px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT.name()}; border-radius: 1px; }}
QSlider::handle:horizontal {{ background: {WHITE.name()}; width: 12px; margin: -5px 0; border-radius: 6px; }}
QScrollBar:vertical {{ background: transparent; width: 6px; }}
QScrollBar::handle:vertical {{ background: rgba(255,255,255,50); border-radius: 3px; min-height: 20px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
"""


class Window(QWidget):
    W = 420
    H = 800

    def __init__(self):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowTitle(f"{TITLE_1} {TITLE_2}")
        self.setFixedSize(self.W, self.H)
        self.move(30, 30)
        self.bg_alpha = 225
        self.started_at = None
        self._last_screen = None

        self.settings = {
            "confidence": 0.8, "interval": 3.0, "queue_timeout": 10.0, "max_match": 35.0,
            "idle_every": 45.0, "anti_idle": True, "press_key": False, "key": "f6",
        }
        self.bot = Bot(self.settings)
        self._build()

        bridge.log.connect(self.add_log)
        bridge.show_window.connect(self.show)
        bridge.emergency.connect(self.emergency_stop)
        QShortcut(QKeySequence("F10"), self, activated=self.emergency_stop)
        if kb is not None:
            try:
                kb.add_hotkey("f10", lambda: bridge.emergency.emit())
            except Exception:
                pass

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(200)

    # ---------- painting / dragging ----------
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect()).adjusted(0.8, 0.8, -0.8, -0.8)
        path = QPainterPath()
        path.addRoundedRect(rect, 16, 16)
        bg = QLinearGradient(0, 0, self.width() * 0.6, self.height())
        a = self.bg_alpha
        bg.setColorAt(0.0, QColor(30, 16, 82, a))
        bg.setColorAt(0.5, QColor(12, 11, 52, a))
        bg.setColorAt(1.0, QColor(6, 7, 30, a))
        p.fillPath(path, bg)
        edge = QLinearGradient(0, 0, self.width(), self.height())
        edge.setColorAt(0.0, QColor(150, 80, 255, 200))
        edge.setColorAt(0.5, QColor(50, 110, 255, 140))
        edge.setColorAt(1.0, QColor(150, 80, 255, 200))
        p.setPen(QPen(edge, 1.6))
        p.drawPath(path)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() < 230 and self.windowHandle():
            self.windowHandle().startSystemMove()

    def fade_in(self):
        self.setWindowOpacity(0.0)
        self._fade = QPropertyAnimation(self, b"windowOpacity")
        self._fade.setDuration(500)
        self._fade.setStartValue(0.0)
        self._fade.setEndValue(1.0)
        self._fade.setEasingCurve(QEasingCurve.OutCubic)
        self._fade.start()

    def shake(self):
        x, y = self.x(), self.y()
        a = QPropertyAnimation(self, b"pos")
        a.setDuration(340)
        offs = (0, -12, 12, -9, 9, -5, 5, 0)
        for i, o in enumerate(offs):
            a.setKeyValueAt(i / (len(offs) - 1), QPoint(x + o, y))
        a.start()
        self._shake = a

    # ---------- layout ----------
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 10, 20, 10)
        root.setSpacing(0)

        top = QHBoxLayout()
        top.addWidget(make_label(VERSION, 8, DIM, False, "Segoe UI"))
        top.addStretch()
        b_min = AnimButton("-", "ghost", 11, 26)
        b_min.setFixedWidth(30)
        b_min.clicked.connect(self.showMinimized)
        b_close = AnimButton("x", "ghost", 10, 26)
        b_close.setFixedWidth(30)
        b_close.clicked.connect(self.close)
        top.addWidget(b_min)
        top.addSpacing(4)
        top.addWidget(b_close)
        root.addLayout(top)

        self.hero = Hero()
        root.addWidget(self.hero)

        for text in (TITLE_1, TITLE_2):
            lab = make_label(text, 33, ACCENT, True, "Segoe UI Black", 0, True)
            lab.setAlignment(Qt.AlignCenter)
            glow(lab, ACCENT, 30, 150)
            root.addWidget(lab)
        root.addSpacing(4)

        self.status = make_label("STOPPED", 11, ICE, True, "Segoe UI", 1.5, True)
        self.status.setAlignment(Qt.AlignCenter)
        root.addWidget(self.status)
        self.screen_lbl = make_label("Screen: --", 9, DIM)
        self.screen_lbl.setAlignment(Qt.AlignCenter)
        self.fx = QGraphicsOpacityEffect(self.screen_lbl)
        self.screen_lbl.setGraphicsEffect(self.fx)
        root.addWidget(self.screen_lbl)

        self.stack = QStackedWidget()
        self.stack_fx = QGraphicsOpacityEffect(self.stack)
        self.stack.setGraphicsEffect(self.stack_fx)
        self.stack.addWidget(self._page_main())
        self.stack.addWidget(self._page_settings())
        root.addWidget(self.stack, 1)

        root.addSpacing(6)
        foot = make_label("F10 = emergency stop  |  unofficial, not affiliated with Epic Games", 8, DIM)
        root.addWidget(foot, 0, Qt.AlignHCenter)

    def _page_main(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 12, 0, 0)
        lay.setSpacing(10)

        hb = QHBoxLayout()
        hb.setContentsMargins(34, 0, 34, 0)
        self.main_btn = AnimButton("START", "accent", 21, 70, skew=True, family="Segoe UI Black",
                                   italic=True, spacing=2)
        self.main_btn.clicked.connect(self.toggle)
        hb.addWidget(self.main_btn)
        lay.addLayout(hb)

        small = QHBoxLayout()
        small.setSpacing(8)
        small.setContentsMargins(8, 0, 8, 0)
        for text, fn in (("CHECK SCREEN", self.check_screen), ("TEST CLICK SPOT", self.test_click),
                         ("SETTINGS", lambda: self.goto(1))):
            b = AnimButton(text, "dark", 9, 34, family="Segoe UI", spacing=0.3)
            b.clicked.connect(fn)
            small.addWidget(b)
        lay.addLayout(small)

        self.cb_key = QCheckBox("Also press F6 after clicking")
        self.cb_key.setStyleSheet(f"QCheckBox {{ color: {ICE.name()}; }}")
        self.cb_key.toggled.connect(lambda v: self.settings.__setitem__("press_key", v))
        lay.addWidget(self.cb_key, 0, Qt.AlignHCenter)

        stats = QHBoxLayout()
        stats.addStretch()
        self.s_queued = StatInline("QUEUED")
        self.s_click = StatInline("LAST CLICK", "--")
        stats.addWidget(self.s_queued)
        stats.addSpacing(26)
        stats.addWidget(self.s_click)
        stats.addStretch()
        lay.addLayout(stats)
        self.sub = make_label("MATCHES: 0   |   RUNTIME: 00:00:00", 8, DIM, False, "Segoe UI", 0.8)
        self.sub.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.sub)

        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(90)
        self.log_box.setFont(QFont("Consolas", 9))
        self.log_box.setStyleSheet("QTextEdit { background: rgba(0,0,0,70); border: 1px solid "
                                   "rgba(255,255,255,22); border-radius: 6px; padding: 6px; "
                                   f"color: {WHITE.name()}; }}")
        lay.addWidget(self.log_box, 1)
        self.add_log("Ready. Open SETTINGS and capture your templates first.")
        return w

    def _spin(self, key, lo, hi, step, decimals=0):
        sp = QDoubleSpinBox() if decimals else QSpinBox()
        if decimals:
            sp.setDecimals(decimals)
        sp.setRange(lo, hi)
        sp.setSingleStep(step)
        sp.setValue(self.settings[key])
        sp.valueChanged.connect(lambda v, k=key: self.settings.__setitem__(k, float(v)))
        return sp

    def _page_settings(self):
        page = QWidget()
        pl = QVBoxLayout(page)
        pl.setContentsMargins(0, 10, 0, 0)
        pl.setSpacing(8)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; } "
                             "QScrollArea > QWidget > QWidget { background: transparent; }")
        inner = QWidget()
        g = QGridLayout(inner)
        g.setContentsMargins(10, 0, 14, 0)
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(8)
        rows = [("Match confidence", "confidence", 0.5, 1.0, 0.05, 2),
                ("Check interval (s)", "interval", 1, 30, 1, 0),
                ("Queue timeout (min)", "queue_timeout", 1, 60, 1, 0),
                ("Max match (min)", "max_match", 5, 90, 1, 0),
                ("Anti-idle every (s)", "idle_every", 10, 300, 5, 0)]
        for i, (label, key, lo, hi, step, dec) in enumerate(rows):
            g.addWidget(make_label(label, 9, WHITE), i, 0)
            g.addWidget(self._spin(key, lo, hi, step, dec), i, 1)
        r = len(rows)
        cb = QCheckBox("Anti-idle mouse nudge during match")
        cb.setChecked(True)
        cb.toggled.connect(lambda v: self.settings.__setitem__("anti_idle", v))
        g.addWidget(cb, r, 0, 1, 2)
        g.addWidget(make_label("Key pressed after Play", 9, WHITE), r + 1, 0)
        ke = QLineEdit("f6")
        ke.setMaximumWidth(80)
        ke.textChanged.connect(self._key_changed)
        g.addWidget(ke, r + 1, 1)
        g.addWidget(make_label("Transparency", 9, WHITE), r + 2, 0)
        sl = QSlider(Qt.Horizontal)
        sl.setRange(70, 255)
        sl.setValue(self.bg_alpha)
        sl.valueChanged.connect(self._set_alpha)
        g.addWidget(sl, r + 2, 1)
        top = QCheckBox("Always on top")
        top.setChecked(True)
        top.toggled.connect(self._set_topmost)
        g.addWidget(top, r + 3, 0, 1, 2)

        g.addWidget(make_label("TEMPLATES", 8, ACCENT, True, "Bahnschrift", 1.5), r + 4, 0)
        self.combo = QComboBox()
        self.combo.addItems(list(CATEGORIES))
        g.addWidget(self.combo, r + 4, 1)
        bc = AnimButton("CAPTURE", "dark", 9, 30, family="Segoe UI", spacing=0.3)
        bc.clicked.connect(self.capture)
        bo = AnimButton("OPEN FOLDER", "dark", 9, 30, family="Segoe UI", spacing=0.3)
        bo.clicked.connect(self.open_folder)
        g.addWidget(bc, r + 5, 0)
        g.addWidget(bo, r + 5, 1)
        self.tmpl_lbl = make_label("", 8, DIM)
        g.addWidget(self.tmpl_lbl, r + 6, 0, 1, 2)
        g.setColumnStretch(0, 1)
        g.setRowStretch(r + 7, 1)
        scroll.setWidget(inner)
        pl.addWidget(scroll, 1)

        back = AnimButton("BACK", "accent", 11, 38, skew=True, family="Segoe UI Black", italic=True, spacing=2)
        back.clicked.connect(lambda: self.goto(0))
        pl.addWidget(back)
        self._refresh_tmpl()
        return page

    # ---------- small helpers ----------
    def goto(self, idx):
        if self.stack.currentIndex() == idx:
            return
        if idx == 1:
            self._refresh_tmpl()
        out = QPropertyAnimation(self.stack_fx, b"opacity")
        out.setDuration(130)
        out.setStartValue(1.0)
        out.setEndValue(0.0)

        def mid():
            self.stack.setCurrentIndex(idx)
            inn = QPropertyAnimation(self.stack_fx, b"opacity")
            inn.setDuration(220)
            inn.setStartValue(0.0)
            inn.setEndValue(1.0)
            inn.start()
            self._sw2 = inn

        out.finished.connect(mid)
        out.start()
        self._sw = out

    def _key_changed(self, t):
        self.settings["key"] = t
        self.cb_key.setText(f"Also press {t.upper() or '...'} after clicking")

    def _refresh_tmpl(self):
        parts = [f"{c}: {len(list(TEMPLATE_DIR.glob(c + '*.png')))}" for c in CATEGORIES]
        self.tmpl_lbl.setText("captured  -  " + "   ".join(parts))

    def _set_alpha(self, v):
        self.bg_alpha = int(v)
        self.update()

    def _set_topmost(self, on):
        self.setWindowFlag(Qt.WindowStaysOnTopHint, on)
        self.show()

    # ---------- log ----------
    def add_log(self, msg):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] {msg}\n")
        except Exception:
            pass
        col = "#ff6b84" if msg.startswith("ERROR") else ("#b9f23c" if ("Match #" in msg or "Clicked" in msg) else "#d7dbe8")
        self.log_box.append(f'<span style="color:#6b7087">{ts}</span>&nbsp;&nbsp;<span style="color:{col}">{msg}</span>')
        self.log_box.verticalScrollBar().setValue(self.log_box.verticalScrollBar().maximum())

    # ---------- periodic UI update ----------
    def _tick(self):
        running = self.bot.running()
        self.hero.set_active(running)
        self.status.setText("RUNNING" if running else "STOPPED")
        self.status.setStyleSheet(f"color: {(ACCENT if running else ICE).name()}; background: transparent;")
        self.main_btn.set_kind("danger" if running else "accent")
        self.main_btn.set_text("STOP" if running else "START")

        name = STATE_NAMES.get(self.bot.state, "--")
        if name != self._last_screen:
            self._last_screen = name
            self.screen_lbl.setText(f"Screen: {name}")
            self._sfade = QPropertyAnimation(self.fx, b"opacity")
            self._sfade.setDuration(280)
            self._sfade.setStartValue(0.1)
            self._sfade.setEndValue(1.0)
            self._sfade.start()

        self.s_queued.set_value(str(self.bot.queued))
        self.s_click.set_value(self.bot.last_click)
        secs = int(time.time() - self.started_at) if (self.started_at and running) else 0
        self.sub.setText(f"MATCHES: {self.bot.matches}   |   RUNTIME: "
                         f"{secs // 3600:02d}:{secs % 3600 // 60:02d}:{secs % 60:02d}")

    # ---------- actions ----------
    def toggle(self):
        if self.bot.running():
            self.bot.stop()
            self.add_log("Stop requested...")
            return
        missing = [c for c in CATEGORIES if not list(TEMPLATE_DIR.glob(f"{c}*.png"))]
        if missing:
            QMessageBox.warning(self, "Missing templates",
                                "Open SETTINGS and capture at least one template for: " + ", ".join(missing))
            return
        self.bot.matches = 0
        self.bot.queued = 0
        self.bot.last_click = "--"
        self.started_at = time.time()
        self.bot.start()

    def emergency_stop(self):
        self.bot.stop()
        self.add_log("EMERGENCY STOP (F10)")

    def _hidden_worker(self, work):
        self.hide()

        def run():
            time.sleep(2)
            try:
                work()
            except Exception as e:
                bridge.log.emit(f"ERROR: {e!r}")
            time.sleep(0.8)
            bridge.show_window.emit()

        threading.Thread(target=run, daemon=True).start()

    def check_screen(self):
        self.add_log("Checking screen...")

        def work():
            for cat in CATEGORIES:
                if not self.bot.files(cat):
                    bridge.log.emit(f"  {cat}: no templates captured")
                    continue
                pt = self.bot.find(cat)
                bridge.log.emit(f"  {cat}: found at ({pt.x}, {pt.y})" if pt else f"  {cat}: not on screen")

        self._hidden_worker(work)

    def test_click(self):
        self.add_log("Moving the mouse to the Play button (no click)...")

        def work():
            pt = self.bot.find("play")
            if pt:
                pyautogui.moveTo(pt.x, pt.y, duration=0.6)
                bridge.log.emit(f"Play button at ({pt.x}, {pt.y})")
                time.sleep(1.2)
            else:
                bridge.log.emit("Play button not found on screen")

        self._hidden_worker(work)

    def open_folder(self):
        try:
            os.startfile(TEMPLATE_DIR)
        except Exception:
            QMessageBox.information(self, "Templates folder", str(TEMPLATE_DIR))

    def capture(self):
        cat = self.combo.currentText()
        QMessageBox.information(self, "Capture", f"Category: {cat}\n({CATEGORIES[cat]})\n\n"
                                "Show that screen in Fortnite, press OK, then drag a box around the button. "
                                "ESC cancels.")
        self.hide()
        QTimer.singleShot(500, lambda: self._start_snip(cat))

    def _start_snip(self, cat):
        self._shot = pyautogui.screenshot()
        self._snip = Snip(self._shot)
        self._snip.done.connect(lambda box, c=cat: self._snip_done(box, c))

    def _snip_done(self, box, cat):
        self.show()
        if box is None:
            self.add_log("Capture cancelled")
            return
        n = len(list(TEMPLATE_DIR.glob(f"{cat}*.png"))) + 1
        path = TEMPLATE_DIR / f"{cat}_{n}.png"
        self._shot.crop(box).save(path)
        self.add_log(f"Saved template {path.name}")
        self._refresh_tmpl()

    def closeEvent(self, e):
        self.bot.stop()
        if kb is not None:
            try:
                kb.unhook_all()
            except Exception:
                pass
        super().closeEvent(e)
        QApplication.quit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(APP_QSS)
    win = Window()
    win.show()
    win.fade_in()
    sys.exit(app.exec())
